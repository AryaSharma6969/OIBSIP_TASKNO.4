import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Login extends JFrame implements ActionListener{
    JButton login,exit;
    JTextField tfname;
    Login(){
        getContentPane().setBackground(Color.LIGHT_GRAY);
        setLayout(null);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Images/login.jpeg"));
        JLabel image = new JLabel(i1);
        image.setBounds(0, 0, 600, 470);
        add(image);
        
        JLabel heading = new JLabel("ONLINE QUIZ");
        heading.setBounds(750, 60, 300, 45);
        heading.setFont(new Font("Times New Roman", Font.BOLD, 40));
        add(heading);

        JLabel name = new JLabel("Enter Your Name");
        name.setBounds(810, 150, 300, 20);
        name.setFont(new Font("Times New Roman", Font.BOLD, 20));
        add(name);

        tfname = new JTextField();
        tfname.setBounds(740, 200, 300, 25);
        tfname.setFont(new Font("Times New Roman", Font.BOLD, 20));
        add(tfname);

        login = new JButton("Login");
        login.setBounds(735, 270, 120, 25);
        login.addActionListener(this);
        add(login);

        
        exit = new JButton("Exit");
        exit.setBounds(915, 270, 120, 25);
        exit.addActionListener(this);
        add(exit); 


        setSize(1200, 500);
        setLocation(200,150);
        setVisible(true);
    }

    public void actionPerformed (ActionEvent ae){
        if(ae.getSource()== login){
            String name = tfname.getText();
            setVisible(false);
            new Instructions(name);
        }
        else if(ae.getSource()== exit){
            setVisible(false);
        }

    }
    public static void  main(String[]args){
        new Login();
    }
}