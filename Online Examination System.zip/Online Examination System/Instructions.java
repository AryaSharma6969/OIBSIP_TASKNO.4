import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Instructions extends JFrame implements ActionListener{
    String name;
    JButton start, logout;
    Instructions(String name){
        this.name = name;
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        JLabel heading = new JLabel("Login Successful, "+name+"." );
        heading.setBounds(50, 20, 700, 30);
        heading.setFont(new Font("Times New Roman", Font.BOLD, 22));
        add(heading);

        JLabel instructions = new JLabel();
        instructions.setBounds(20, 90, 700, 350);
        instructions.setFont(new Font("Times New Roman", Font.PLAIN, 16));
        instructions.setText(
        "<html>"+
            "1. This exam is MCQ based questions." + "<br><br>"+
            "2. Please select any 1 out of 4 options." + "<br><br>"+
            "3. There are 10 MCQ's." + "<br><br>"+
            "4. Each question carries 10 marks." + "<br><br>" +
            "5. Total Exam marks are 100." + "<br><br>"+
            "6. You will get 15 seconds for each question, make sure to attempt within time." + "<br><br>"+
            "7. There is a special option for 50-50 Lifeline, it simply removes 2 wrong options from the options." + "<br><br>"+
            "8. You can use 50-50 Lifeline once in the whole game." + "<br><br>"+
            "9. All the best for your exam." + "<br><br>"+
        "<html>"   
        );
        add(instructions);
        
        start = new JButton("Start");
        start.setBounds(250, 500, 100, 30);
        start.addActionListener(this);
        add(start);

        logout = new JButton("Logout");
        logout.setBounds(400, 500, 100, 30);
        logout.addActionListener(this);
        add(logout);

        setSize(800, 650);
        setLocation(350, 100);
        setVisible(true);
    }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==start){
            setVisible(false);
            new Quiz(name);
        }
        else{
            setVisible(false);
            new Login();
        }
    }
    public static void main(String[] args){
        new Instructions("User");

    }
}
